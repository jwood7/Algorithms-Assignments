/*******************************************************************************
 * Name    : waterjugpuzzle.cpp
 * Author  : Brandon Kreiser, Jacob Wood
 * Version : 1.0
 * Date    : October 19, 2020
 * Description : Solves the water jug puzzle
 * Pledge : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/
#include <iostream>
#include <sstream>
#include <queue>
#include <stack>
#include <vector>

using namespace std;

//Struct to represent state of water in the jugs.
struct State {
    int a, b, c;
    string directions;
    State *parent;
    
    State(int _a, int _b, int _c, string _directions) :
        a{_a}, b{_b}, c{_c}, directions{_directions}, parent{nullptr} { }
    
    // String representation of state in tuple form.
    string to_string() {
        ostringstream oss;
        oss << "(" << a << ", " << b << ", " << c << ")";
        return oss.str();
    }
};

vector<vector<State>> seen_states;

State bfs(State start, State goal, int capacities[]) {
	queue<State> q;
	State fail_state(0, 0, 0, "No solution.");

	for (int i = 0; i <= capacities[1] + 1; i++) {
		vector<State> inner_vector;
		for(int i = 0; i <= capacities[2] + 1; i++) {
			inner_vector.push_back(fail_state);
		}
		seen_states.push_back(inner_vector);
	}


	q.push(start);

	while(!q.empty()) {
		State current = q.front();
		q.pop();

		if(current.to_string() == goal.to_string()) {
			return current;
		}
		if(seen_states[current.a][current.b].to_string() == fail_state.to_string()){
			seen_states[current.a][current.b] = current;

			//C to A
			if (current.c != 0) {
				int max_amount_transferrable = capacities[1] - current.a;

				if(max_amount_transferrable < current.c) {
					State c_a(current.a + max_amount_transferrable, current.b, current.c - max_amount_transferrable, "Pour " + to_string(max_amount_transferrable) + " gallons from C to A.");

					if (max_amount_transferrable == 1) {
						c_a.directions = "Pour 1 gallon from C to A.";
					}

					c_a.directions = c_a.directions + " " + c_a.to_string();
					c_a.parent = &(seen_states[current.a][current.b]);
					q.push(c_a);
				} else {
					State c_a(current.a + current.c, current.b, 0, "Pour " + to_string(current.c) + " gallons from C to A.");

					if (current.c == 1) {
						c_a.directions = "Pour 1 gallon from C to A.";
					}

					c_a.directions = c_a.directions + " " + c_a.to_string();
					c_a.parent = &(seen_states[current.a][current.b]);
					q.push(c_a);
				}
			}

			//B to A
			if (current.b != 0) {
				int max_amount_transferrable = capacities[1] - current.a;

				if(max_amount_transferrable < current.b) {
					State b_a(current.a + max_amount_transferrable, current.b - max_amount_transferrable, current.c, "Pour " + to_string(max_amount_transferrable) + " gallons from B to A.");

					if (max_amount_transferrable == 1) {
						b_a.directions = "Pour 1 gallon from B to A.";
					}

					b_a.directions = b_a.directions + " " + b_a.to_string();
					b_a.parent = &(seen_states[current.a][current.b]);
					q.push(b_a);
				} else {
					State b_a(current.a + current.b, 0, current.c, "Pour " + to_string(current.b) + " gallons from B to A.");

					if (current.b == 1) {
						b_a.directions = "Pour 1 gallon from B to A.";
					}

					b_a.directions = b_a.directions + " " + b_a.to_string();
					b_a.parent = &(seen_states[current.a][current.b]);
					q.push(b_a);
				}
			}

			//C to B
			if (current.c != 0) {
				int max_amount_transferrable = capacities[2] - current.b;

				if(max_amount_transferrable < current.c) {
					State c_b(current.a, current.b + max_amount_transferrable, current.c - max_amount_transferrable, "Pour " + to_string(max_amount_transferrable) + " gallons from C to B.");

					if (max_amount_transferrable == 1) {
						c_b.directions = "Pour 1 gallon from C to B.";
					}

					c_b.directions = c_b.directions + " " + c_b.to_string();
					c_b.parent = &(seen_states[current.a][current.b]);
					q.push(c_b);

				} else {
					State c_b(current.a, current.b + current.c, 0, "Pour " + to_string(current.c) + " gallons from C to B.");
					c_b.directions = c_b.directions + " " + c_b.to_string();

					if (current.c == 1) {
						c_b.directions = "Pour 1 gallon from C to B.";
					}

					c_b.parent = &(seen_states[current.a][current.b]);
					q.push(c_b);
				}
			}

			//A to B
			if (current.a != 0) {
				int max_amount_transferrable = capacities[2] - current.b;

				if(max_amount_transferrable < current.a) {
					State a_b(current.a - max_amount_transferrable, current.b + max_amount_transferrable, current.c, "Pour " + to_string(max_amount_transferrable) + " gallons from A to B.");

					if (max_amount_transferrable == 1) {
						a_b.directions = "Pour 1 gallon from A to B.";
					}

					a_b.directions = a_b.directions + " " + a_b.to_string();
					a_b.parent = &(seen_states[current.a][current.b]);
					q.push(a_b);
				} else {
					State a_b(0, current.b + current.a, current.c, "Pour " + to_string(current.a) + " gallons from A to B.");

					if (current.a == 1) {
						a_b.directions = "Pour 1 gallon from A to B.";
					}

					a_b.directions = a_b.directions + " " + a_b.to_string();
					a_b.parent = &(seen_states[current.a][current.b]);
					q.push(a_b);
				}
			}

			//B to C
			if (current.b != 0) {
				int max_amount_transferrable = capacities[3] - current.c;

				if(max_amount_transferrable < current.b) {
					State b_c(current.a, current.b - max_amount_transferrable, current.c+ max_amount_transferrable, "Pour " + to_string(max_amount_transferrable) + " gallons from B to C.");

					if (max_amount_transferrable == 1) {
						b_c.directions = "Pour 1 gallon from B to C.";
					}

					b_c.directions = b_c.directions + " " + b_c.to_string();
					b_c.parent = &(seen_states[current.a][current.b]);
					q.push(b_c);
				} else {
					State b_c(current.a, 0, current.c + current.b, "Pour " + to_string(current.b) + " gallons from B to C.");

					if (current.b == 1) {
						b_c.directions = "Pour 1 gallon from B to C.";
					}

					b_c.directions = b_c.directions + " " + b_c.to_string();
					b_c.parent = &(seen_states[current.a][current.b]);
					q.push(b_c);
				}
			}

			//A to C
			if (current.a != 0) {
				int max_amount_transferrable = capacities[3] - current.c;

				if(max_amount_transferrable < current.a) {
					State a_c(current.a - max_amount_transferrable, current.b, current.c+ max_amount_transferrable, "Pour " + to_string(max_amount_transferrable) + " gallons from A to C.");

					if (max_amount_transferrable == 1) {
						a_c.directions = "Pour 1 gallon from A to C.";
					}

					a_c.directions = a_c.directions + " " + a_c.to_string();
					a_c.parent = &(seen_states[current.a][current.b]);
					q.push(a_c);
				} else {
					State a_c( 0, current.b, current.c + current.a, "Pour " + to_string(current.a) + " gallons from A to C.");

					if (current.a == 1) {
						a_c.directions = "Pour 1 gallon from A to C.";
					}

					a_c.directions = a_c.directions + " " + a_c.to_string();
					a_c.parent = &(seen_states[current.a][current.b]);
					q.push(a_c);
				}
			}
		}
	}
	return fail_state;
}

int main(int argc, char* const argv[]) {
	int caps[4], goals[4];
	char letters[4] = {'x', 'A', 'B', 'C'};
	istringstream iss;

	//check for proper usage
	if (argc != 7) {
		cerr << "Usage: ./waterjugpuzzle <cap A> <cap B> <cap C> <goal A> <goal B> <goal C>" << endl;
		return 0;
	}

	//check for valid integer inputs
	for (int i = 1; i < 7 ; i++) {
		iss.str(argv[i]);
		if(i < 4) {
			if (!(iss >> caps[i]) || caps[i] <= 0) {
				cerr << "Error: Invalid capacity '" << iss.str() << "' for jug "<< letters[i] << "." << endl;
				return 1;
			}
		} else {
			if (!(iss >> goals[i - 3]) || goals[i - 3] < 0) {
				cerr << "Error: Invalid goal '" << iss.str() << "' for jug " << letters[i - 3] << "." << endl;
				return 1;
			}
		}
		iss.clear();
	}

	//checks for valid goals
	for (int i = 1; i < 4; i++) {
		if (goals[i] > caps[i]) {
			cerr << "Error: Goal cannot exceed capacity of jug " << letters[i] << "." << endl;
			return 1;
		}
	}

	//makes sure the total goals are equal to the capacity of C
	if(goals[1] + goals[2] + goals[3] != caps[3]) {
		cerr << "Error: Total gallons in goal state must be equal to the capacity of jug C." << endl;
		return 1;
	}

	State start_state(0, 0, caps[3], "Initial state. ");
	start_state.directions += start_state.to_string();

	State goal_state(goals[1], goals[2], goals[3], "Goal state.");

	if (goal_state.c == start_state.c){
		cout<< start_state.directions <<endl;
	}else{

		State end_state = bfs(start_state, goal_state, caps);

		if(end_state.directions != "No solution.") {
			State current = end_state;
			stack<State> stack;

			while (current.parent != nullptr){
				stack.push(current);
				current = *(current.parent);
			}

			cout << current.directions << endl;

			while (stack.size() > 1) {
				cout << (stack.top()).directions << endl;
				stack.pop();
			}

			cout << (stack.top()).directions;

		} else {
			cout << "No solution.";
		}
	}

    return 0;
}
