/*******************************************************************************
 * Name        : minishell.c
 * Author      : Jacob Wood
 * Date        : April 14, 2021
 * Description : minishell implementation.
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/
 
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <dirent.h>
#include <sys/wait.h>
#include <pwd.h>

#define BRIGHTBLUE "\x1b[34;1m" 
#define DEFAULT    "\x1b[0m"


volatile sig_atomic_t signal_val = 0;

void catch_signal(int sig) {
    signal_val = sig;
}



int main(){

     char **inp = (char **) calloc(2048, sizeof(char*));
        if (inp == NULL){
            fprintf(stderr,"Error: malloc() failed. %s.\n", strerror(errno));
        }
        for ( int i = 0; i < 2048; i++ ){
            inp[i] = (char*) calloc(2048, sizeof(char));
            if (inp[i] == NULL){
                fprintf(stderr,"Error: malloc() failed. %s.\n", strerror(errno));
            }
        }

//To Do:
// How big should my input array be?
    
    	//Parent
    	bool exited = false;
        char dir[PATH_MAX];
        if(getcwd(dir,sizeof(dir)) == NULL){
   	    fprintf(stderr, "Error: Cannot get current working directory. %s.\n", strerror(errno)); 
        }
    
        struct sigaction sa;
    
        memset(&sa, 0,sizeof(struct sigaction));
        sa.sa_handler = catch_signal;
        sigemptyset(&sa.sa_mask);
    
        if(sigaction(SIGINT, &sa, NULL) < 0) {
            fprintf(stderr, "Error: Cannot register signal handler. %s.\n", strerror(errno)); 
            return EXIT_FAILURE;
        }
        
        //main loop: 
        
        while(!exited){
        char input[2048]; //2048?
        if (signal_val == 2){
            signal_val = 0;
            printf("\n");
        }else{
        
        printf("[%s%s%s]$ ",BRIGHTBLUE,dir,DEFAULT);
        //fgets(input, sizeof(input), stdin);
        
        if (fgets(input, sizeof(input), stdin) == NULL && errno != EINTR){
            if (errno == 0){
            printf("\n");
            return EXIT_FAILURE;
            }else{
            fprintf(stderr, "Error: Failed to read from stdin. %s.\n", strerror(errno)); 
            return EXIT_FAILURE;
            }
        }
        
        
        if (signal_val == 2){
            signal_val = 0;
            printf("\n");
            continue;
        }
        
        //Parsing input:
        int ai = 0;
        int aii = 0;
        bool quote = false;
        
        for(int i = 0; i<2048; i++){
    	    for (int k = 0; i<2048; i++){
    	    	inp[i][k] = '\0';
    	    }
        } 
        
        for(int i = 0; i<2048; i++){
    	    if(input[i] == '"'){ 
    	        quote = !quote;
    	    }else if (input[i] == ' ' && quote == false){
    	        inp[ai][aii] = '\0';
    	        ai++;
    	        aii = 0;
    	    }else if (input[i] == '\n'){
    	        inp[ai][aii] = '\0';
    	        aii++;
    	        break;
    	    }else{
                inp[ai][aii] = input[i];
                aii++;
    	    }
        } 
        if (quote == true){
    	    printf("Error: Malformed command.\n"); 
    	    continue;
        }
        
        if(strcmp(input,"exit\n")==0){ 
            for ( int i = 0; i < 2048; i++ ){
                free(inp[i]);
            }
            free(inp);
    	    return EXIT_SUCCESS;
        }
        
        
        if (strcmp(inp[0],"cd")==0){
            if (strcmp(inp[2],"")!=0){
    	        printf("Error: Too many arguments to cd.\n"); 
    	        continue;
            }
            if (strcmp(inp[1],"~")==0 || strcmp(inp[1],"")==0){
                char *homedir = getpwuid(getuid())->pw_dir;
                if (homedir == NULL){
                    fprintf(stderr,"Error: Cannot get passwd entry. %s.\n" , strerror(errno));
                    return EXIT_FAILURE;
                }
                strcpy(inp[1],homedir);
            }else if(inp[1][0] == '~'){
                char *homedir = getpwuid(getuid())->pw_dir; 
                if (homedir == NULL){
                    fprintf(stderr,"Error: Cannot get passwd entry. %s.\n" , strerror(errno));
                    return EXIT_FAILURE;
                }       
                for (int i = 0; i<2048;i++){
            	    if (inp[1][i+1] == '\0'){
            	        break;
            	    }
                    char temp[2];
                    temp[0]= inp[1][i+1];
                    temp[1] = '\0';
                    strcat(homedir,temp);
                }
                strcpy(inp[1],homedir);
            }
            if(chdir(inp[1])<0){
                fprintf(stderr,"Error: Cannot change directory to '%s'. %s.\n", inp[1], strerror(errno));
            }else{
                if(getcwd(dir,sizeof(dir)) == NULL){
   	      	    fprintf(stderr, "Error: Cannot get current working directory. %s.\n", strerror(errno)); 
    	        }
            }
            
        continue;
        }
        
        if (inp[0][0] == '\0'){
            continue;
        }
        
        
        pid_t pid;
    	if((pid=fork())<0){
    	     fprintf(stderr, "Error: fork() failed. %s.\n", strerror(errno));
    	} else if (pid > 0){
        int status;
        do {
    	    pid_t w = waitpid(pid, &status, WUNTRACED | WCONTINUED);
    	    if(w == -1 && errno != EINTR){
    	        fprintf(stderr, "Error: wait() failed. %s.\n", strerror(errno));
    	        exit(EXIT_FAILURE);
    	    }
    	    
        } while (!WIFEXITED(status) && !WIFSIGNALED(status)); 
   
        }else{
    
    	char *funccall = strdup(inp[0]); 
    	//char *inp[2048];
    	for (int i = 0; i<2048; i++){
    	    if (strcmp(inp[i],"")==0){
    	        inp[i] = NULL;
    	    }else{
    	        inp[i] = strdup(inp[i]);
    	    }
    	}
        if (execvp(funccall, inp) == -1) {
            fprintf(stderr, "Error: execv() failed. %s.\n", strerror(errno));            
            exit(EXIT_FAILURE);        
        }
        
        
        
        
        
        
        
   
    
    }
   
    }
    
            
        
        
    }



/*
Error Handling Errors for system/function calls should be handled as they have been in previous assignments.  
At a minimum, you will need to incorporate the following error messages into your shell.  
The last %s in each line below is a format specifier for strerror(errno).
"Error: Cannot get passwd entry. %s.\n" //for ... ?? 
"Error: Cannot change directory to '%s'. %s.\n" //cd
"Error: Too many arguments to cd.\n" //cd
"Error: Failed to read from stdin. %s.\n" //for read 
"Error: fork() failed. %s.\n" 
"Error: exec() failed. %s.\n" 
"Error: wait() failed. %s.\n" 
"Error: malloc() failed. %s.\n"   // If you use malloc(). 
"Error: Cannot get current working directory. %s.\n" 
"Error: Cannot register signal handler. %s.\n" 

If you use other system/function calls, follow a similar format for the corresponding error messages. 

*/


return EXIT_FAILURE;
}
